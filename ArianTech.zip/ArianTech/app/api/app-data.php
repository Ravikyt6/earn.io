<?php
require_once('../includes/init.php');

$res = (object) array();

$res->success = $APP_AVAILABLE;
$res->message = $DEV_MESSAGE;

if ( $m_mode == 1) {
	$res->success = false;
	$res->message = 'Maintenance mode';
}

$res->app_version = (int) $app_version;
$res->app_url = $app_url;

$res->vpn_required = $vpn_task_only == 1 ? null : $vpn_required;

$res->tg_channel = $tg_channel;
$res->support_group = $support_group;
$res->startapp=$startapp;

$res->ban_ad = $ban_ad ?? '';

if($multi_task == '1' && empty($_GET['task-app'])) {
	$res->vpn_required = null;
}

if ( $_GET['task-app'] == 1 ) {
	$res->ban_ad = $ban1;
}

if ( $_GET['task-app'] == 2 ) {
	$res->ban_ad = $ban2;
}

if ( $_GET['task-app'] == 3 ) {
	$res->ban_ad = $ban3;
}

if ( $_GET['task-app'] == 4 ) {
	$res->ban_ad = $ban4;
}

echo json_encode($res);
?>