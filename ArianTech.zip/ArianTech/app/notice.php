<?php
session_start();
require_once('includes/init.php');

if(!empty($_GET['cp']) && !empty($_GET['cge'])) {
    $_SESSION['cp'] = $_GET['cp'];
    $_SESSION['cge'] = $_GET['cge'];
}

if($_GET['app'] == 'main') {
	$_SESSION['main_app'] = "1";
}

$_SESSION['token'] = $_COOKIE['token'] ?? null;

if ( !isset($_SESSION['token']) ) {
	header('location: login.php?' . http_build_query($_GET));
}

$token = $_SESSION['token'];

$user_data = get_user_by_token($conn, $token);

if ( empty( $user_data ) ) header('location: login.php?' . http_build_query($_GET));
?>
<!DOCTYPE html>
<html>
<head>
	<title>Notice</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=false">
	<link rel="stylesheet" href="css/style.css" >
	<link defer rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" >
	<link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@500&display=swap" rel="stylesheet">
	<style>
		<?php include 'css/custom-style.php' ?>
	</style>
</head>
<body class="bg-primary">  
<section class="topbar">
   <br><br><br><br><br><br>
</section>
<div class="notice-bg">
<div class="notice-block">
<div class="left" style="font-family: 'Hind Siliguri', sans-serif;text-align: left;font-size: 20px; ">
		<?= nl2br( text2link($home_notice) ) ?>
	</div>
</div></div>
<section class="footer">
          <font onclick="Android.openWebActivity('Developer', 'infinitylabbd')"> Developed by EDU FAST</font>
       </section>
</body>
</html>