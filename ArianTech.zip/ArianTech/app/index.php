<?php
session_start();
require_once('includes/init.php');

if(!empty($_GET['cp']) && !empty($_GET['cge'])) {
    $_SESSION['cp'] = $_GET['cp'];
    $_SESSION['cge'] = $_GET['cge'];
}

if($_GET['app'] == 'main') {
	$_SESSION['main_app'] = "1";
}

$_SESSION['token'] = $_COOKIE['token'] ?? null;

if ( !isset($_SESSION['token']) ) {
	header('location: login.php?' . http_build_query($_GET));
}

$token = $_SESSION['token'];

$user_data = get_user_by_token($conn, $token);

if ( empty( $user_data ) ) header('location: login.php?' . http_build_query($_GET));
?>
<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=false">
	<link rel="stylesheet" href="css/style.css" >
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link defer rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" >
	<link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@500&display=swap" rel="stylesheet">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <!-- SweetAlert2 -->
  <link href="//cdn.jsdelivr.net/npm/@sweetalert2/theme-minimal/minimal.css" rel="stylesheet">
<script src="//cdn.jsdelivr.net/npm/sweetalert2@10/dist/sweetalert2.min.js"></script>
	<style>
		<?php include 'css/custom-style.php' ?>
		#htw button {
		    border: none;
	        font-weight: bold;
	        border-radius: 5px;
	        padding: 5px;
	        height: 60px;
        	width: 240px;
	        color: white;
	        outline: none;
	        margin: 10px auto;
	        display: inline-block;
	        background: #4CAF50;
	        box-shadow: 1px 1px 1px 1px rgba(0,0,0,0.2);
		}
	</style>
</head>
<body class="bg-primary">
   <div class="">
       <section class="profile">
           <!--<h3 style="text-align: left; padding: 4px"> Welcome Back <span style="float: right" 
           onClick="location.reload();"><i class="fa fa-spinner fa-spin" style="font-size:18px"></i></span></h3>-->
           <div class="user-block">
               <div class="icon">
                   <img src="https://fftzone.xyz/appicon/edu.png" height="100px" width="100px"/>
               </div>
               <div class="userinfo">
                   <h4> <?= $user_data['fname'] ?? 'Rakibul Hasan Moni' ;?></h4>
                   <h4 style="color : #e8e8e8"> <?= $user_data['mobile'] ?? '1234' ; ?></h4> <br>
                   <h4 style="color : #eee">Your Balance:</h4>
                   <h4><i class='fas fa-coins'></i> <?= $user_data['balance'] ?? '1000' ;?></h4>
               </div>
           </div>
       </section>
       <section class="block-header">
           <div class="title">
               
           </div>
       </section>   
       <section class="block-main"><center>
           <div class="line1">
               <div id="vpn" onclick="Android.taskActivity()" class="item">
                   <img src="https://fftzone.xyz/appicon/taskone.png" height="100px" width="80px"/> <br>
                   <span id="off">Start Task</span>
               </div>
               <div onclick="Android.openWebActivity('Profile', 'profile')" class="item">
                   <img src="https://fftzone.xyz/appicon/profile.png" height="100px" width="80px"/> <br>
                   Profile
               </div>
               
                <div id="d_succes" class="item">
             
                   <img src="https://fftzone.xyz/appicon/bonus.png" height="80px" width="100px"/> <br>
                   Daily Bonus
               </div>
               
           </div></center><center>
            <div class="line1">
               <div onclick="Android.openWebActivity('Leaderboard', 'leaderboard')" class="item">
                   <img src="https://fftzone.xyz/appicon/leader.png" height="90px" width="80px"/> <br>
                   Leaderboard
               </div>
               <div onclick="Android.openWebActivity('Wallet', 'wallet')" class="item">
                   <img src="https://fftzone.xyz/appicon/wallet.png" height="90px" width="100px"/> <br>
                   Withdraw
               </div>
               <div onclick="Android.openWebActivity('Payment History', 'payments')" class="item">
                   <img src="https://fftzone.xyz/appicon/hist2.png" height="90px" width="80px"/> <br>
                   History
               </div>
           </div></center>
           <center>
            <div class="line1">
               <div onclick="Android.openWebActivity('Refer & Earn', 'refer')" class="item">
                   <img src="https://fftzone.xyz/appicon/re2.png" height="80px" width="80px"/> <br>
                   Refer & Earn
               </div>
               <div onclick="Android.openWebActivity('Notice', 'notice')" class="item">
                   <img src="https://fftzone.xyz/appicon/noti.png" height="100px" width="80px"/> <br>
                   Notice
               </div>
               <div onclick="location.href='<?= $support_group ?>'" class="item">
                   <img src="https://fftzone.xyz/appicon/suport.png" height="100px" width="80px"/> <br>
                   Support
               </div>
           </div></center>
       </section>
       <section class="footer">
          <font onclick="Android.openWebActivity('Developer', 'infinitylabbd')"> Developed by EDU FAST</font>
       </section>
   </div>




















	<!--
	<section class="profile-wrapper">
		
		<div class="user-info">
			<h2 class="masque"><?= $user_data['fname'] ?></h2>
			<strong><?= $user_data['mobile'] ?></strong>
		</div>
		
		<div id="userData">
		
		<table class="user-data">
			<tr>
				<td>Balance<p><?= $user_data['balance'] ?></p>
				<td rowspan="2" class="divider"><p></p></td>
				<td>Invalid Click<p><?= $user_data['i_click'] ?></p></td>
			</tr>
			<tr>
				<td>Total Refer<p><?= $user_data['t_ref'] ?></p>
				<td>Refer Code<p><?= $user_data['mobile'] ?></p></td>
			</tr>
		</table>
		
		</div>
	</section>
	
	<div class="notice-container" style="font-family: 'Hind Siliguri', sans-serif;text-align: left; ">
		<?= nl2br( text2link($home_notice) ) ?>
	</div>
	
	<?php if(!empty($htw_link)) : ?>
		<a id="htw" href="<?= $htw_link ?>"><button>How To Work</button></a>
	<?php endif ?>
	
	<?php if($multi_task == '1') : ?>
		<section>
			<?php if( $user_data['i_click'] > $invalid_limit ) : ?>
				<button class="earn-btn-exodus">Account Blocked</button>
				<script>Android.blockAlert(1)</script>
			<?php else : ?>
				<div class="btn-container">
					<a href="<?= $task1_url ?? '#'?>"><button>App 1</button></a>
					<a href="<?= $task2_url ?? '#'?>"><button>App 2</button></a>
					<a href="<?= $task3_url ?? '#'?>"><button>Job 3</button></a>
					<a href="<?= $task4_url ?? '#'?>"><button>Job 4</button></a>
				</div>
			<?php endif ?>
		</section>
		
	<?php else : ?>

		<section class="earn-btns">
			<?php if( $user_data['i_click'] > $invalid_limit ) : ?>
			
				<button class="earn-btn-exodus">Account Blocked</button>
				<script>Android.blockAlert(1)</script>
			
			<?php elseif ( $task_enabled == 0 ) : ?>
			
				<button class="earn-btn-exodus">Task Closed</button>
			
			<?php else : ?>
			
				<button id="task-btn" class="earn-btn-exodus" onclick="Android.taskActivity()">Start Task</button>
			
			<?php endif ?>
	
	<br><br><br><br><br><br>
		<font style="text-align: center; color : white;" onclick="Android.openWebActivity('Developer', 'infinitylabbd')"> Developed by: EDU FAST</font>	
			
		</section>
		
	<?php endif ?>
	
	-->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			setInterval(function () {
				$('#userData').load('user-data.php')
			}, 4000);
		});
		Android.setUserAccount("<?= base64_encode($token) ?>");
	</script>
    	<?php if( $req_vpn == 1 ) : ?>
    		<script> 
    	let allowedLocations = "<?= $cn_list ?>";

$.get("https://ipinfo.io?token=<?= $i_key ?>", function(response) {
  if(!allowedLocations.includes(response.country)) {
    $('#vpn').prop("onclick", null).off("click");
    $('#off').html('Connect VPN');
   
  };
}, "jsonp")
    	</script>
    	
    	
    	<?php endif ?>
	    <script>
    	   $(document).on('click', '#vpnoff', function(e) {
			swal.fire(
				title: 'VPN Required!',
			 text: "Please connect vpn!",
			 type: 'warning',
			 buttons: false, 
			 allowOutsideClick: false
			)
		});

    	</script>
    	<?php if( $user_data['d_bonus'] == 1) :?>
    	<script>
    	   $(document).on('click', '#d_succes', function(e) {
			swal.fire(
				'Sorry!',
				'Already Claimed!',
				'error'
			)
		});

    	</script>
    	
    	<?php else :?>  
    	<script type="text/javascript">
        $(document).ready(function(){
            $("#d_succes").click(function(){

                    swal.fire({title:'Bonus', 
                        text:'Do you want to collect daily bonus?', 
                        icon:'warning', 
                        buttons: true, 
                        dangerMode: true,
                        allowOutsideClick: false
                    })
                    .then((willOUT) => {
                            if (willOUT) {
                                  window.location.href = 'dbtf.php', {
                                  icon: 'success',
                                }
                              }
                    });

            });
        });
    </script>
    <?php endif ?> 
</body>
</html>