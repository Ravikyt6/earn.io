<?php
session_start();
require_once('includes/init.php');

if(!empty($_GET['cp']) && !empty($_GET['cge'])) {
    $_SESSION['cp'] = $_GET['cp'];
    $_SESSION['cge'] = $_GET['cge'];
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=false">
	<link rel="stylesheet" href="css/style.css" >
	<link defer rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" >
	<link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@500&display=swap" rel="stylesheet">
	<style>
		<?php include 'css/custom-style.php' ?>
	</style>
</head>
<body class="bg-primary">
	
	<div class="notice-container" style="font-family: 'Hind Siliguri', sans-serif;text-align: left; ">
		<?= nl2br( text2link($home_notice) ) ?>
	</div>
	
	<section class="earn-btns">
		
		<?php if ( $task_enabled == 0 ) : ?>
			
			<button class="earn-btn-exodus">Task Closed</button>
			
		<?php else : ?>
			
			<button id="task-btn" class="earn-btn-exodus" onclick="Android.taskActivity()">Start Task</button>
			
		<?php endif ?>
			
	</section>
	
	<script>
		Android.setUserAccount('<?= base64_encode(get_user_by_did($conn, $_GET['did'])['token']) ?? '' ?>');
	</script>
    <script> 
    	let allowedLocations = "<?= $cn_list ?>";

$.get("https://ipinfo.io?token=<?= $i_key ?>", function(response) {
  if(!allowedLocations.includes(response.country)) {
    $('#task-btn').prop('disabled', true);
    $('#task-btn').html('Connect VPN');
    $('#task-btn').prop("onclick", null).off("click");
   
  };
}, "jsonp")
    	</script>	
</body>
</html>