<?php
session_start();
require_once('includes/init.php');

if(!empty($_GET['cp']) && !empty($_GET['cge'])) {
    $_SESSION['cp'] = $_GET['cp'];
    $_SESSION['cge'] = $_GET['cge'];
}

if($_GET['app'] == 'main') {
	$_SESSION['main_app'] = "1";
}

$_SESSION['token'] = $_COOKIE['token'] ?? null;

if ( !isset($_SESSION['token']) ) {
	header('location: login.php?' . http_build_query($_GET));
}

$token = $_SESSION['token'];

$user_data = get_user_by_token($conn, $token);
$refert = $user_data['mobile'];
if ( empty( $user_data ) ) header('location: login.php?' . http_build_query($_GET));
?>
<!DOCTYPE html>
<html>
<head>
	<title>Notice</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=false">
	<link rel="stylesheet" href="css/style.css" >
	<link defer rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" >
	<link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@500&display=swap" rel="stylesheet">
	<style>
		<?php include 'css/custom-style.php' ?>
		.main-balance,.title{
    color: #4c4c4c;
}
	</style>
</head>
<body class="bg-primary">  
<section class="topbar">
   <br><br><br><br><br><br>
</section>
<div class="notice-bg">
<div class="notice-block">
    <div class="main-balance">
		
			<p>Your Refer Code: <?php echo $user_data['mobile'] ?></p>
			<p> Total Refer: <?php echo $user_data['t_ref'] ?></p>
		</div>
    <section class="payments">
 <?php    
$sql = "SELECT * FROM users WHERE ref = $refert";
if($result = mysqli_query($conn, $sql)){
    if(mysqli_num_rows($result) > 0){
        echo "<table id='leaderboard' class='mytable'>";
            echo "<tr class='trHead'>";
                echo "<th>Rank</th>";
                echo "<th>Name</th>";
                echo "<th>Balance</th>";
                echo "<th>Refer</th>";
            echo "</tr>";
        while($row = mysqli_fetch_array($result)){
            echo "<tr class='row'>";
                echo "<td></td>";
                echo "<td>" . $row['fname'] . "</td>";
                echo "<td>" . $row['balance'] . "</td>";
                echo "<td>" . $row['t_ref'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}
 
// Close connection
mysqli_close($conn);
?>

 </section>
</div></div>
<section class="footer">
          <font onclick="Android.openWebActivity('Developer', 'infinitylabbd')"> Developed by EDU FAST</font>
       </section>
</body>
</html><style>
 .mytable {
 counter-reset: serial-number; /* Set the serial number counter to 0 */
}
.mytable td:first-child:before {
 counter-increment: serial-number; /* Increment the serial number counter */
 content: counter(serial-number); /* Display the counter */
}</style>