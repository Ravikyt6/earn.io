<?php 
session_start();
require_once('includes/init.php');

if (!isset($_SESSION['token'])) {
	exit;
}

$token = $_SESSION['token'];

$user_data = get_user_by_token($conn, $token);

if ( empty( $user_data ) ) exit;
?>
	
<table class="user-data">
	<tr>
		<td>Balance<p><?= $user_data['balance'] ?></p>
		<td rowspan="2" class="divider"><p></p></td>
		<td>Invalid Click<p><?= $user_data['i_click'] ?></p></td>
	</tr>
	<tr>
		<td>Total Refer<p><?= $user_data['t_ref'] ?></p>
		<td>Refer Code<p><?= $user_data['mobile'] ?></p></td>
	</tr>
</table>