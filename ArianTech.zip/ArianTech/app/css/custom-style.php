<?php
require_once( __DIR__ . '/../../dev-control.php' );

if(!empty($_SESSION['cp']) && !empty($_SESSION['cge'])) {
    $bg_primary = 'linear-gradient( #' . $_SESSION['cp'] . ', #' . $_SESSION['cge'] . ' );';
} else {
   $bg_primary = 'linear-gradient( ' . _COLOR_PRIMARY_ . ', ' . _COLOR_GRADIENT_END_ . ' );';
   $bg_top = 'linear-gradient( ' . _COLOR_PRIMARY_ . ', ' . _COLOR_PRIMARY_ . ' );';
}
?>
*{ margin:0 ;padding=0;}
.bg-primary { background: #f0f8ff !important; }
.bg-main { background: <?= $bg_top ?> !important; }
.profile { 
      background: <?= $bg_top ?> !important;
      border-bottom-left-radius: 80px 80px;
      padding: 10px;
      
}
.userinfo{
    float: left;
    padding: 15px;
    text-align: left;
    width: 50%;
    margin: 0;
}    
.icon { 
    float: left;
    width: 40%;
    margin-right: 10px; 
}    
.user-block {
    display: inline-block ;
    width: 100%;
}
.line1{
    display: inline-block ;
    width: 100%;
    margin:0 auto;
    display: flex;
    justify-content: center;
    align-items: center;
}
.item {
    float: left;
    width: 26%;
    margin:0 auto;
    margin: 8px;
    color: black;
    background: white;
    border: 1px solid #e8e8e8;
    border-radius: 8px ;
    padding: 6px;
    display: inline-block ;
}
.block-main{
   width: 100%;
   margin:0 auto;
   margin-bottom: 100px;
}
.block-header{
   margin-top: 10px;
   padding: 10px;
}
.footer {
   position: fixed;
   left: 0;
   margin-top: 120px;
   bottom: 0;
   width: 100%;
   background: <?= $bg_top ?> !important;
   color: white;
   padding: 20px;
   text-align: center;
   border-radius: 25px 25px 0px 0px;
}
.notice-block {
    float: left;
    width: 80%;
    margin:0 auto;
    margin: 8px;
    color: black;
    background: white;
    border: 1px solid #e8e8e8;
    border-radius: 15px ;
    padding: 6px;
    display: inline-block ;
    -ms-transform: translateY(-100px);
    transform: translateY(-100px);
}
.topbar { 
      background: <?= $bg_top ?> !important;
      border-radius:0px 0px 60px 60px;
      padding: 10px;
      
}
.notice-bg {
    display: flex;
    justify-content: center;
    align-items: center;
}
