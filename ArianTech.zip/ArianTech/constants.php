<?php

define( '_DB_NAME_', 'doinikne_ex' );

define( '_COLOR_PRIMARY_', '#883BA2' );
define( '_COLOR_GRADIENT_END_', '#F97794' );