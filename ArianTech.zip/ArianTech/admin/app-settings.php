<?php
session_start();

require_once('functions.php');
require_once('dbconnection.php');
require_once('includes/init.php');

$password = $_SESSION['password'];
$admin_data = get_admin($conn, $password);
if ($password != $admin_data['password']) {
	header('location: login.php');
}
if ( !isset($_SESSION['password']) ) {
	header('location: login.php');
}
if ( empty( $admin_data ) ) header('location: login.php');
$pageTitle = 'App Settings';

$data_file = "app-data.json";
$success = false ;

if ( isset($_POST['submit']) ) {
	$data = json_decode(file_get_contents($data_file), true) ?? array();
	$data = array_merge($data, $_POST);
	file_put_contents($data_file, json_encode($data, JSON_PRETTY_PRINT));
	snack ("success", "Success");
	$success = true ;
}

$app_data = json_decode(file_get_contents($data_file), true);

foreach( $app_data as $key => $val ) {
	$$key = $val;
}

?>
<!DOCTYPE html>
<html>
	<head>
		<title>App Settings</title>
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=false, shrink-to-fit=no">
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		<script src='https://kit.fontawesome.com/a076d05399.js'></script>

	</head>
	<body class="bg-gray-200">
		<?php include("header.php") ?>
	<main>
	<div class="fr-container fr-lg pb-0">
	    <section>
				<div class="mx-2 col-sm">
				         <?php if ($success) :?>
				    <div class="alert alert-success">
                       <strong>Success!</strong> changes Saved.
                         </div>
                    <?php endif ?>
					<form class="py-3" action="" autocomplete="off" method="POST">
						<h4 class="py-2">Task Settings</h4>
					<section class="row">
						<div class="form-group col-sm">
							<label>Task [ 1 = Enabled ]</label>
							<input name="task_enabled" value="<?= $task_enabled ?? '' ?>" type="number" class="form-control" required>
						</div>
						<div class="form-group col-sm">
							<label>Task Reward</label>
							<input name="task_reward" value="<?= $task_reward ?? '' ?>" type="number" class="form-control" required>
						</div>
						</section>
					<section class="row">
						<div class="form-group col-sm">
							<label>Refer Comission</label>
							<input name="ref_comission" value="<?= $ref_comission ?? ''?>" type="number" class="form-control" required>
						</div>
						<div class="form-group col-sm">
							<label>Invalid Click Limit</label>
							<input name="invalid_limit" value="<?= $invalid_limit ?? ''?>" type="number" class="form-control" required>
						</div>
						</section>
						<section class="row">
						<div class="form-group col-sm">
							<label>Per Refer Points</label>
							<input name="refer_points" value="<?= $refer_points ?? ''?>" type="number" class="form-control" required>
						</div>
						<div class="form-group col-sm">
							<label>Daily Rewards Points</label>
							<input name="daily_rewards" value="<?= $daily_rewards ?? ''?>" type="number" class="form-control" required>
						</div>
						</section>
					<section class="row">
						<div class="form-group col-sm">
							<label>View Before Click - View Target</label>
							<input name="view_target" value="<?= $view_target ?? '' ?>" type="number" class="form-control" required>
						</div>
						<div class="form-group col-sm">
							<label>Task Limit</label>
							<input name="task_limit" value="<?= $task_limit ?? '' ?>" type="number" class="form-control" required>
						</div>
						</section>
					<section class="row">
						<div class="form-group col-sm">
							<label>Task Break Time (Minutes)</label>
							<input name="task_timer" value="<?= $task_timer ?? '' ?>" type="number" class="form-control" required>
						</div>
						<div class="form-group col-sm">
							<label>Impression Wait Time (Seconds)</label>
							<input name="impression_time" value="<?= $impression_time ?? '' ?>" type="number" class="form-control" required>
						</div>
						</section>
					<section class="row">
						<div class="form-group col-sm">
							<label>Click Wait Time (Seconds)</label>
							<input name="click_time" value="<?= $click_time ?? '' ?>" type="number" class="form-control" required>
						</div>
						<div class="form-group col-sm">
							<label>Button Timer (Seconds)</label>
							<input name="button_timer" value="<?= $button_timer ?? '' ?>" type="number" class="form-control" required>
						</div></section>
						<h4 class="py-2"> VPN Settings</h4>
					
					<section class="row">
						<div class="form-group col-sm">
							<label>VPN Required [Enter 1 for TRUE]</label>
							<input name="req_vpn" value="<?= $req_vpn ?? '0' ?>" type="number" class="form-control" required>
						</div>
						<div class="form-group col-sm">
							<label>Task Only [VPN Required in Task Only]</label>
							<input name="vpn_task_only" value="<?= $vpn_task_only ?? '0' ?>" type="number" class="form-control" required>
						</div>
						</section>
					<section class="row">
						<div class="form-group col-sm">
							<label>Allowed Country</label>
							<input name="cn_list" value="<?= $cn_list ?? '' ?>" type="text" class="form-control" required>
						</div>
						<div class="form-group col-sm">
							<label>IPINFO API Key</label>
							<input name="i_key" value="<?= $i_key ?? '' ?>" type="text" class="form-control" required>
						</div>
						</section>
					<h4 class="py-2">App Settings</h4>
					<section class="row">
					<div class="form-group col-sm">
						<label>Maintenance Mode [App Off]</label>
						<input name="m_mode" value="<?= $m_mode ?? '' ?>" type="number" autocorrect="off" autocapitalize="none" class="form-control" required>
					</div>
					<div class="form-group col-sm">
						<label>Show Payment Nav [Public Payments]</label>
						<input name="payment_nav" value="<?= $payment_nav ?? '' ?>" type="number" autocorrect="off" autocapitalize="none" class="form-control" required>
					</div>
					</section>
					<section class="row">
					<div class="form-group col-sm">
						<label>Task only on Registration Device</label>
						<input name="task_did" value="<?= $task_did ?? '' ?>" type="number" autocorrect="off" autocapitalize="none" class="form-control" required>
					</div>
					
					<div class="form-group col-sm">
						<label>Withdraw Status</label>
						<select name="withdraw_status" class="form-control">
							<?php
								$op3 = ( $withdraw_status == 1 ) ? 'Open' : 'Close';
							?>
							<option value="<?= $withdraw_status ?? '' ?>" hidden><?= $op3 ?></option>
							<option value="1">Open</option>
							<option value="0">Close</option>
						</select>
					</div></section>
						<h4 class="py-2">Registration Settings</h4>
					<section class="row">
						<div class="form-group col-sm">
							<label>Default Refer Code</label>
							<input name="default_ref" value="<?= '1234' ?>" type="number" class="form-control" required>
						</div>
						<div class="form-group col-sm">
							<label>Registration Status</label>
							<select name="reg_status" class="form-control">
								<?php
									$option = ( $reg_status == 1 ) ? 'Open' : 'Close';
								?>
								<option value="<?= $reg_status ?? '' ?>" hidden><?= $option ?></option>
								<option value="1">Open</option>
								<option value="0">Close</option>
							</select>
						</div>
						</section>
					<h4 class="py-2"> Social Settings</h4>
					<section class="row">
					<div class="form-group col-sm">
						<label>Telegram Channel Link</label>
						<input name="tg_channel" value="<?= $tg_channel ?? '' ?>" type="text" autocorrect="off" autocapitalize="none" class="form-control" required>
					</div>
					<div class="form-group col-sm">
						<label>Support Group Link</label>
						<input name="support_group" value="<?= $support_group ?? '' ?>" type="text" autocorrect="off" autocapitalize="none" class="form-control" required>
					</div>
					<div class="form-group col-sm">
						<label>STARTAPP APP ID</label>
						<input name="startapp" value="<?= $startapp ?? '' ?>" type="text" autocorrect="off" autocapitalize="none" class="form-control" required>
					</div>
					</section>
					<section class="row">
					<div class="form-group col-sm">
						<label>How To Work Link</label>
						<input name="htw_link" value="<?= $htw_link ?? '' ?>" type="text" autocorrect="off" autocapitalize="none" class="form-control">
					</div></section>
					<section class="row">
					    </section>
					<h4 class="py-2"> Version Control</h4>
					    <section class="row">
					<div class="form-group col-sm">
						<label>App Version</label>
						<input name="app_version" value="<?= $app_version ?? '' ?>" type="number" autocorrect="off" autocapitalize="none" class="form-control" required>
					</div>
					<div class="form-group col-sm">
						<label>App Link</label>
						<input name="app_url" value="<?= $app_url ?? '' ?>" type="text" autocorrect="off" autocapitalize="none" class="form-control" required>
					</div>
					</section>
					<button name="submit" type="submit" class="fab bg-primary material-icons border-0">check</button>
				</form>
				
				</div>
			</section></div>
		</main>
		<?php include('footer.php') ?>
	</body>
</html>